# dsh-lexicon-shield

给 DeepSeek Harness (dsh) 用的**输入侧代号护盾**：你打的某些词，在消息进入会话之前被换成代号；模型读到的、日志里存的都是代号，你自己知道那是什么。

单向、可逆、零风险——它**只改你输入的那一步**，不碰模型输出流，所以不可能把你的会话弄坏。

## 它做什么 / 不做什么

| | |
|---|---|
| 做 | 在 `agent/pre-step` 里改写即将写入会话的用户消息（真词 → 代号） |
| 做 | 把代号表注入系统提示词，让模型读懂代号 |
| 做 | 词表 JSON 热加载（改完 1 秒生效，不用重启） |
| 不做 | 不改模型输出，不还原代号（这条路上翻过车，放弃了） |
| 不做 | 不碰 `llm/stream`、不碰请求对象、不碰工具调用 |

## 安装

```bash
# 1) 装包（把 tgz 路径换成你实际的）
dsh plugin --profile web add /path/to/dsh-lexicon-shield-4.0.0.tgz

# 2) 复制一份词表模板
cp lexicon.sample.json ~/.dsh/lexicon-shield.json

# 3) 重启 dsh web（插件层是启动时挂载的）
```

启动后确认挂上了：

```bash
grep lexicon-shield ~/dsh-web.log | tail -3
# [lexicon-shield] 已挂载（输入侧脱敏，开关文件=...）
# [lexicon-shield] 词表启动加载：N 条
```

## 配词

词表长这样（`~/.dsh/lexicon-shield.json`）：

```json
{
  "version": 1,
  "protect": ["受保护的整体词"],
  "pairs": [
    { "real": "你的真词甲", "code": "代号一" },
    { "real": "你的真词乙", "code": "代号一" },
    { "real": "你的真词丙", "code": "代号二" }
  ]
}
```

- **多对一**：多个真词可以对应同一个代号。
- **长词优先**：`长词组` 会先匹配，不会被单字拆碎。
- **单字真词**：支持，但容易误伤，配 `protect` 用。
- **单字代号**：建议用圈号 `①②③` 或符号 `★♠`，不会和正文撞字。

### 命令行（推荐，别手写 JSON）

```bash
python3 add-pair.py list                       # 看全表（真词只显示字数）
python3 add-pair.py add "你的真词" "代号"       # 加一条
python3 add-pair.py del "你的真词"              # 按真词整组删除
python3 add-pair.py check "一段测试话"          # 先模拟编码，再决定加不加
python3 add-pair.py protect "超市"              # 加保护词（单字替换防误伤）
python3 add-pair.py unprotect "超市"
python3 add-pair.py plist                      # 看保护名单
```

## 临时停用 / 恢复

```bash
touch ~/.dsh/lexicon-shield.off    # 立即停用，不用重启
rm ~/.dsh/lexicon-shield.off       # 立即恢复
```

## 配置项

| 键 | 默认 | 说明 |
|---|---|---|
| `enabled` | `true` | 总开关 |
| `mode` | `"encode"` | `encode` 替换；`off` 不动 |
| `injectPrompt` | `true` | 是否把代号表注入系统提示词 |
| `ignoreCase` | `true` | 英文代号大小写不敏感 |
| `lexiconPath` | `~/.dsh/lexicon-shield.json` | 词表路径 |
| `killSwitchPath` | `~/.dsh/lexicon-shield.off` | 开关文件路径 |
| `pollMs` | `1000` | 词表轮询间隔 |
| `debug` | `false` | 打每步改写条数 |

覆盖默认值：在你自己的 profile 的 `cordis.patch.yml` 里写同名 id：

```yaml
- insert:
    - id: lexicon-shield
      name: dsh-lexicon-shield
      config:
        debug: true
```

## 卸载

```bash
dsh plugin --profile web remove dsh-lexicon-shield
rm ~/.dsh/lexicon-shield.json ~/.dsh/lexicon-shield.off
# 重启 dsh web
```

## 注意

- **词表里存的是你的词**，别把 `~/.dsh/lexicon-shield.json` 发给别人。
- 这个插件只降低"敏感词触达模型"的概率，**不保证绕过任何服务端审核**；审核是语义级的，代号也可能被读懂。
- 代号用久了会形成稳定映射，建议定期轮换，或给同一个词配第二套代号。

MIT License
