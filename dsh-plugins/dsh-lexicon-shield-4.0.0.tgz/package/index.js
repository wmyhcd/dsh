/**
 * dsh-lexicon-shield v4 —— 输入侧脱敏（单向，不碰输出流）。
 *
 * 前几版的教训：在 `llm/stream` 上改写输出，等于在一条"会被严格校验、压缩、
 * 重放的记录流"上动刀，缺 index 就整轮报废。v4 彻底放弃那条路，改成：
 *
 *   在用户打的字进会话之前，把真词换成代号。
 *
 * 接缝选在 `agent/pre-step`：agent-loop 会拿它返回值的 `messages` 去
 * `session.append("user/message", …)`（dsh-agent-loop/lib/index.js:1046），
 * 所以改这里 = 改"将要写进日志的那条消息"，日志与后续 deriveMessages() 天然一致，
 * 不会触发请求重建不变量。
 *
 * 绝不触碰：llm/stream、请求对象、assistant 输出。最坏情况只是"没替换"。
 *
 * @module dsh-lexicon-shield
 */

import { existsSync, readFileSync, statSync, unwatchFile, watchFile } from "node:fs";
import { homedir } from "node:os";
import { join, resolve } from "node:path";

export const name = "dsh-lexicon-shield";
export const inject = ["systemPrompt"];

export const SECTION_NAME = "dsh-lexicon-shield:codebook";
export const SECTION_ORDER = 178;

export const DEFAULT_CONFIG = Object.freeze({
  enabled: true,
  mode: "encode",
  injectPrompt: true,
  lexiconPath: join(homedir(), ".dsh", "lexicon-shield.json"),
  killSwitchPath: join(homedir(), ".dsh", "lexicon-shield.off"),
  pollMs: 1000,
  ignoreCase: true,
  debug: false,
});

const EMPTY_LEXICON = Object.freeze({ pairs: [] });

/**
 * 读词表。
 * @param {string} file
 * @returns {{pairs: Array<{real: string, code: string}>}}
 */
export function loadLexicon(file) {
  const raw = JSON.parse(readFileSync(file, "utf8"));
  const list = Array.isArray(raw) ? raw : raw?.pairs;
  if (!Array.isArray(list)) throw new Error("词表必须是数组，或形如 {pairs:[...]} 的对象");
  const pairs = [];
  for (const item of list) {
    const real = typeof item?.real === "string" ? item.real.trim() : "";
    const code = typeof item?.code === "string" ? item.code.trim() : "";
    // 允许单字真词：只排除空串与自己映射自己
    if (real.length === 0 || code.length === 0 || real === code) continue;
    pairs.push({ real, code });
  }
  const rawProtect = Array.isArray(raw?.protect) ? raw.protect : [];
  const protect = rawProtect.filter((w) => typeof w === "string" && w.length > 0);
  return { pairs, protect };
}

/**
 * 建"真词 → 代号"编码器（长词优先）。
 * @param {{pairs: Array<{real: string, code: string}>}} lexicon
 * @param {boolean} ignoreCase
 */
export function buildEncoder(lexicon, ignoreCase = true) {
  const protectList = Array.isArray(lexicon?.protect) ? lexicon.protect : [];
  const protectPattern =
    protectList.length === 0
      ? null
      : new RegExp(
          protectList
            .slice()
            .sort((a, b) => b.length - a.length)
            .map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
            .join("|"),
          ignoreCase ? "gi" : "g",
        );
  const map = new Map();
  for (const { real, code } of lexicon.pairs) {
    const key = ignoreCase ? real.toLowerCase() : real;
    if (!map.has(key)) map.set(key, code);
  }
  const keys = [...map.keys()].sort((a, b) => b.length - a.length);
  if (keys.length === 0) return { map, pattern: null, protectPattern: null, encode: (t) => t };
  const pattern = new RegExp(
    keys.map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|"),
    ignoreCase ? "gi" : "g",
  );
  /** 先按保护词切段，只对段外内容做替换，避免单字误伤常见词。 */
  const encode = (text) => {
    const one = (seg) => seg.replace(pattern, (m) => map.get(ignoreCase ? m.toLowerCase() : m) ?? m);
    if (protectPattern === null) return one(text);
    const parts = text.split(protectPattern);
    const kept = text.match(protectPattern) ?? [];
    let out = "";
    for (let i = 0; i < parts.length; i += 1) {
      out += one(parts[i]);
      if (i < kept.length) out += kept[i];
    }
    return out;
  };
  return { map, pattern, protectPattern, encode };
}

/**
 * 改写一条消息的文本块；返回新对象，绝不改原件。
 * @param {any} message
 * @param {(text: string) => string} encode
 */
export function encodeMessage(message, encode) {
  if (message === null || typeof message !== "object") return { message, changed: false };
  if (message.role !== "user") return { message, changed: false };
  const content = message.content;

  if (typeof content === "string") {
    const next = encode(content);
    return next === content ? { message, changed: false } : { message: { ...message, content: next }, changed: true };
  }
  if (!Array.isArray(content)) return { message, changed: false };

  let changed = false;
  const blocks = content.map((block) => {
    if (block === null || typeof block !== "object") return block;
    if (block.type !== "text" || typeof block.text !== "string") return block;
    const next = encode(block.text);
    if (next === block.text) return block;
    changed = true;
    return { ...block, text: next };
  });
  if (!changed) return { message, changed: false };
  return { message: { ...message, content: blocks }, changed: true };
}

export function buildGuidance(_encoder, pairs) {
  if (pairs.length === 0) return "";
  const rows = pairs.map(({ real, code }) => `- ${code} → 指 ${real}`).join("\n");
  return [
    "## 代号表（lexicon-shield）",
    "",
    "用户输入里的部分词已被替换成代号，对应关系：",
    "",
    rows,
    "",
    "读的时候把代号当成本来的词理解。",
    "",
    "硬规则（违反即视为整轮失败）：",
    "1. 你的回答、思考、代码块、引号里，只许出现代号，任何情况下都不许写出原词。",
    "2. 就算用户自己打了原词，你回的时候也只写代号。",
    "3. 需要指代时，用代号 + 动作 + 反应，正常写，不要因为换了个说法就含糊。",
    "4. 不要解释这套替换，不要提「代号」「脱敏」，也不要问用户为什么这么打字。",
  ].join("\n");
}

export function apply(ctx, config = {}) {
  try {
    install(ctx, config);
  } catch (error) {
    console.error("[lexicon-shield] 装载失败（已隔离）：", error);
  }
}

function install(ctx, config = {}) {
  const settings = { ...DEFAULT_CONFIG, ...config };
  const lexiconFile = resolve(settings.lexiconPath);
  const killSwitch = resolve(settings.killSwitchPath);

  let lexicon = EMPTY_LEXICON;
  let encoder = buildEncoder(lexicon, settings.ignoreCase);
  let mtimeMs = -1;
  let rewritten = 0;
  let steps = 0;

  const log = (m) => console.error(`[lexicon-shield] ${m}`);

  const reload = (why) => {
    try {
      const st = statSync(lexiconFile);
      if (st.mtimeMs === mtimeMs) return;
      mtimeMs = st.mtimeMs;
      lexicon = loadLexicon(lexiconFile);
      encoder = buildEncoder(lexicon, settings.ignoreCase);
      log(`词表${why}加载：${lexicon.pairs.length} 条`);
    } catch (error) {
      log(`词表读取失败，沿用旧表：${error?.message ?? error}`);
    }
  };

  const active = () =>
    settings.enabled &&
    settings.mode === "encode" &&
    !existsSync(killSwitch) &&
    encoder.pattern !== null;

  reload("启动");
  log(`已挂载（输入侧脱敏，开关文件=${killSwitch}）`);

  if (settings.injectPrompt) {
    try {
      ctx.effect(
        () =>
          ctx.systemPrompt.section({
            name: SECTION_NAME,
            order: SECTION_ORDER,
            text: () => (settings.enabled ? buildGuidance(encoder, lexicon.pairs) : ""),
          }),
        "dsh-lexicon-shield: codebook",
      );
    } catch (error) {
      log(`提示词段注册失败：${error?.message ?? error}`);
    }
  }

  try {
    ctx.effect(() => {
      const listener = () => reload("热");
      watchFile(lexiconFile, { interval: settings.pollMs }, listener);
      return () => unwatchFile(lexiconFile, listener);
    }, "dsh-lexicon-shield: watch lexicon");
  } catch (error) {
    log(`词表监听失败：${error?.message ?? error}`);
  }

  try {
    ctx.on("session/event", (session, event) => {
      try {
        if (!active()) return;
        if (event?.type !== "assistant/message") return;
        const text = JSON.stringify(event.data ?? "");
        const hits = [];
        for (const { real } of lexicon.pairs) {
          if (text.includes(real)) hits.push(real);
        }
        if (hits.length > 0) {
          log(`⚠ 输出里出现 ${hits.length} 个原词（只记录，不修改内容）`);
        }
      } catch {
        /* 检测失败绝不影响会话 */
      }
    }, { global: true });
  } catch (error) {
    log(`违规检测注册失败：${error?.message ?? error}`);
  }

  ctx.on(
    "agent/pre-step",
    async (payload, next) => {
      const decision = await next();
      try {
        if (!active()) return decision;
        if (decision === null || typeof decision !== "object") return decision;
        if (decision.kind === "reject") return decision;
        const messages = Array.isArray(decision.messages) ? decision.messages : null;
        if (messages === null) return decision;

        let touched = 0;
        const encoded = messages.map((message) => {
          const result = encodeMessage(message, encoder.encode);
          if (result.changed) touched += 1;
          return result.message;
        });

        steps += 1;
        if (touched === 0) {
          if (settings.debug && steps <= 5) log(`第 ${steps} 步：无命中`);
          return decision;
        }
        rewritten += touched;
        log(`第 ${steps} 步：改写 ${touched} 条消息（累计 ${rewritten}）`);
        return { ...decision, messages: encoded };
      } catch (error) {
        log(`改写失败，原样放行：${error?.message ?? error}`);
        return decision;
      }
    },
    { global: true, prepend: true },
  );
}

export default { name, inject, apply };