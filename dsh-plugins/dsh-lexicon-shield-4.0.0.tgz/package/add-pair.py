#!/usr/bin/env python3
"""给 lexicon-shield 词表加/删/查词条。

用法：
  python3 add-pair.py add  <真词> <代号>     # 增一条（同真词同代号会去重）
  python3 add-pair.py del  <真词>           # 按真词删（它对应的所有代号一起删）
  python3 add-pair.py list                  # 列出现有词条（代号侧打码，只显示长度）
  python3 add-pair.py check <一段话>        # 模拟编码结果，先看效果再决定加不加
  python3 add-pair.py protect <词>          # 把词加进保护名单（单字替换时防误伤）
  python3 add-pair.py unprotect <词>        # 从保护名单移除
  python3 add-pair.py plist                 # 查看保护名单

词表路径默认 ~/.dsh/lexicon-shield.json；保存即热加载，不用重启 dsh。
"""
import json
import os
import sys

PATH = os.path.expanduser("~/.dsh/lexicon-shield.json")


def load():
    with open(PATH, encoding="utf-8") as f:
        doc = json.load(f)
    if isinstance(doc, list):
        doc = {"version": 1, "pairs": doc}
    doc.setdefault("pairs", [])
    return doc


def save(doc):
    tmp = PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, PATH)          # 原子替换，插件轮询不会读到半个文件
    print(f"已写入 {PATH}（{len(doc['pairs'])} 条）—— 1 秒内自动生效")


def cmd_add(real, code):
    doc = load()
    for p in doc["pairs"]:
        if p.get("real") == real and p.get("code") == code:
            print("这条已经存在，跳过")
            return
    doc["pairs"].append({"real": real, "code": code})
    save(doc)


def cmd_del(real):
    doc = load()
    before = len(doc["pairs"])
    doc["pairs"] = [p for p in doc["pairs"] if p.get("real") != real]
    if len(doc["pairs"]) == before:
        print("没找到这个词")
        return
    save(doc)
    print(f"删掉 {before - len(doc['pairs'])} 条")


def cmd_protect(word, on=True):
    doc = load()
    protect = doc.setdefault("protect", [])
    if on:
        if word in protect:
            print("已在保护名单里")
            return
        protect.append(word)
        save(doc)
        print(f"已保护「{word}」（{len(protect)} 个）")
    else:
        if word not in protect:
            print("不在保护名单里")
            return
        doc["protect"] = [w for w in protect if w != word]
        save(doc)
        print(f"已解除「{word}」")


def cmd_plist():
    doc = load()
    protect = doc.get("protect", [])
    for i, w in enumerate(protect, 1):
        print(f"{i:>2}. {w}")
    print(f"共 {len(protect)} 个保护词")


def cmd_list():
    doc = load()
    for i, p in enumerate(doc["pairs"], 1):
        real = p.get("real", "")
        code = p.get("code", "")
        print(f"{i:>2}. 真词({len(real)}字) → 「{code}」")
    print(f"共 {len(doc['pairs'])} 条")


def cmd_check(text):
    doc = load()
    for w in sorted(doc.get("protect", []), key=len, reverse=True):
        text = text.replace(w, "\u0000" * len(w))
    pairs = sorted(doc["pairs"], key=lambda p: -len(p.get("real", "")))
    out = text
    hits = []
    for p in pairs:
        real, code = p.get("real", ""), p.get("code", "")
        if real and real in out:
            out = out.replace(real, code)
            hits.append(code)
    out = out.replace("\u0000", "")
    print("编码后:", out)
    print("命中:", ", ".join(hits) if hits else "（无）")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    action = sys.argv[1]
    if action == "add" and len(sys.argv) >= 4:
        cmd_add(sys.argv[2], sys.argv[3])
    elif action == "del" and len(sys.argv) >= 3:
        cmd_del(sys.argv[2])
    elif action == "list":
        cmd_list()
    elif action == "protect" and len(sys.argv) >= 3:
        cmd_protect(sys.argv[2], True)
    elif action == "unprotect" and len(sys.argv) >= 3:
        cmd_protect(sys.argv[2], False)
    elif action == "plist":
        cmd_plist()
    elif action == "check" and len(sys.argv) >= 3:
        cmd_check(sys.argv[2])
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())