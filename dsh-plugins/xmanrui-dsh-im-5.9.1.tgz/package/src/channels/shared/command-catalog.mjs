import { t } from './i18n.mjs';

const TEXT_CHANNELS = Object.freeze(['telegram', 'slack', 'discord', 'whatsapp', 'matrix']);

function defineCatalogCommand(name, description, help, { aliases = [], ...options } = {}) {
  return Object.freeze({
    name,
    description,
    channels: TEXT_CHANNELS,
    menuVisible: true,
    ...options,
    aliases: Object.freeze(aliases.map((alias) => Object.freeze({
      menuVisible: true,
      ...(typeof alias === 'string' ? { name: alias } : alias),
    }))),
    help: Object.freeze(help),
  });
}

// Presentation metadata for TextHarnessBridge commands, in help order.
// Keep each command's aliases, short description and full usage together here.
// Handlers still own parsing and authorization; privateOnly is descriptive.
// enabled: false removes a definition from both consumers; menuVisible: false
// hides a command (or alias) only from the native menu, leaving help available.
export const SHARED_COMMAND_CATALOG = Object.freeze([
  defineCatalogCommand('new', '开启一个全新会话', [
    '/new  开启一个全新会话',
  ]),
  defineCatalogCommand('compact', '压缩当前会话的较早上下文', [
    '/compact  压缩当前会话的较早上下文',
  ]),
  defineCatalogCommand('clear', '清空当前会话上下文并保留会话绑定', [
    '/clear  清空当前会话上下文（保留 Session 绑定和历史记录）',
  ]),
  defineCatalogCommand('history', '查看最近历史消息（仅私聊）', [
    '/history [数量]  查看最近历史消息（默认 3 条，最多 5 条）',
  ], { privateOnly: true }),
  // Merged listing+switch command: no argument opens the picker, an argument
  // switches directly. /wsl and friends stay accepted but leave the menu so
  // there is one workspace entry to choose from.
  defineCatalogCommand('workspace', '查看或切换工作区', [
    '/workspace 或 /ws  查看可切换的工作区（点按钮切换）',
    '/workspace 工作区序号或绝对路径  切换工作区',
  ], { aliases: [{ name: 'ws', menuVisible: false }] }),
  defineCatalogCommand('conv', '设置当前对话专属工作区', [
    '/conv 或 /conversation  查看当前对话工作区',
    '/conv 工作区绝对路径或序号  设置当前对话专属工作区',
    '/conv clear  清除专属工作区，回到 bot 默认工作区',
  ], {
    // Aliases stay typeable and stay in /help, but the native Telegram menu
    // lists each command once; B16 in the command UX audit.
    aliases: [
      { name: 'conversation', menuVisible: false },
      { name: 'thread', menuVisible: false },
    ],
  }),
  defineCatalogCommand('workspacelist', '列出工作区绝对路径', [
    '/workspacelist、/wsl、/workspaces  工作区列表别名（等同 /ws）',
  ], {
    // Aliases stay typeable and stay in /help, but the native Telegram menu
    // lists each command once; B16 in the command UX audit.
    aliases: [
      { name: 'workspaces', menuVisible: false },
      { name: 'wsl', menuVisible: false },
    ],
    menuVisible: false,
  }),
  defineCatalogCommand('sessionlist', '列出会话 ID 和标题', [
    '/sessionlist 或 /sessions [工作区序号或绝对路径]  列出会话 ID 和标题',
    '/sessionlist --limit N  仅列出当前工作区前 N 个会话',
  ], { aliases: [{ name: 'sessions', menuVisible: false }] }),
  defineCatalogCommand('session', '将当前聊天绑定到指定会话', [
    '/session Session ID 或当前工作区序号  将当前聊天绑定到指定会话',
  ]),
  defineCatalogCommand('models', '按序号列出所有可用模型', [
    '/models  按序号列出所有可用模型',
  ]),
  defineCatalogCommand('reasoninglist', '按序号列出当前模型可用推理等级', [
    '/reasoninglist 或 /reasonings  按序号列出当前模型可用推理等级',
  ], { aliases: [{ name: 'reasonings', menuVisible: false }] }),
  defineCatalogCommand('reasoning', '查看或切换当前推理等级', [
    '/reasoning [序号、等级ID或 --default]  查看或切换当前推理等级',
  ]),
  defineCatalogCommand('model', '查看或切换当前会话模型', [
    '/model [序号或完整模型ID] [推理等级ID]  查看或切换当前会话模型',
    '示例：先发 /models，再发 /model 2 [推理等级ID]',
  ]),
  defineCatalogCommand('presetlist', '列出可用 Agent Preset', [
    '/presetlist 或 /presets  按序号列出可用 Agent Preset',
  ], { aliases: [{ name: 'presets', menuVisible: false }] }),
  defineCatalogCommand('preset', '查看或设置新会话 Agent Preset', [
    '/preset [序号或完整ID]  查看或设置当前机器人 Agent Preset',
    '纯数字 ID：/preset id:<ID>',
    '/preset --default  跟随 Host 默认',
  ]),
  defineCatalogCommand('stop', '停止当前任务', [
    '/stop  停止当前任务',
  ]),
  defineCatalogCommand('steer', '纠偏当前任务', [
    '/steer 补充指令  纠偏当前任务',
  ]),
  defineCatalogCommand('batch', '开始批量输入（仅私聊）', [
    '/batch  开始批量输入（仅私聊，最多 10 条文字）',
  ], { privateOnly: true }),
  defineCatalogCommand('send', '提交当前批次', [
    '/send  提交当前批次',
  ], { privateOnly: true }),
  defineCatalogCommand('cancel', '取消当前批次', [
    '/cancel  取消当前批次',
  ], { privateOnly: true }),
  defineCatalogCommand('status', '检查连接状态', [
    '/status  检查连接状态',
  ]),
  defineCatalogCommand('version', '查看插件版本', [
    '/version  查看插件版本',
  ]),
  defineCatalogCommand('help', '显示帮助', [
    '/help  显示本帮助',
  ]),
]);

export function commandsForChannel(channel, catalog = SHARED_COMMAND_CATALOG) {
  return catalog.filter((item) => item.enabled !== false && item.channels.includes(channel));
}

export function commandHelpLines(channel, catalog = SHARED_COMMAND_CATALOG) {
  return commandsForChannel(channel, catalog).flatMap((item) => item.help.map((line) => t(line)));
}
