# dsh-rules

给 DeepSeek Harness 用的「自定义规则」插件：规则写进单文件，每个会话都注入，改完不用重启。

## 你拍板过的四个选择

| 项 | 采用 |
|---|---|
| 存储 | 单文件 `<DSH_HOME>/rules/rules.json` |
| 位置 | 双段夹：head（order 60）+ tail（order 5900） |
| 界面 | 设置 → 「规则」面板（v0.2） |
| 作用域 | 三档，细层覆盖粗层：session > workspace > global |

## 目录

```
<DSH_HOME>/rules/rules.json      规则库（唯一数据源，写前自动备份）
<DSH_HOME>/rules/rules.json.bak-* 备份，保留最近 20 份
<DSH_HOME>/rules/off              kill switch：存在即整体静默
```

## 规则字段

```json
{
  "id": "r-lang",
  "title": "默认中文",
  "text": "始终使用简体中文回答。",
  "enabled": true,
  "priority": 90,
  "scope": { "mode": "global" }
}
```

`scope.mode`：`global` / `workspace`（配 `cwd`）/ `session`（配 `sessionId`）。
同一个 `id` 在不同层各存一条即为覆盖；细层写 `enabled:false` 表示「在这一层关掉」。

## 三种改法

1. **跟助手说**：`rule_add` / `rule_toggle` / `rule_edit` / `rule_drop` / `rule_list` / `rule_check`
2. **面板点**：设置 → 规则
3. **直接改 JSON**：改完下一轮请求即生效（`text` 是函数，每轮重新求值）

## 设计约束

- 注入文本有字符预算（默认 2400），超了按 `priority` 从低到高裁，并在段尾明说裁了几条，不静默。
- JSON 解析失败时沿用上一版缓存，绝不注入半截规则。
- kill switch 一行 `touch <DSH_HOME>/rules/off` 全关。

## 重启后验证清单

```bash
# 1) 依赖与 bundles 都在（两边都要有，缺一不可）
grep -n '"dsh-rules"' /root/.dsh/profiles/web/package.json
dsh --profile web --dump-config | grep -c dsh-rules     # 应为 3

# 2) 宿主侧真的注册了段落与工具：重启后让助手跑 rule_list
# 3) 面板：设置 → 「规则」
```

## 已知坑

- **改过本包 `package.json` 之后要重新 `dsh plugin --profile web add /sdcard/dsh-rules-plugin`**。
  实测：只改 `lib/` 下的源码是安全的（软链即生效），但动了 `package.json` 会让 profile 的
  依赖被重解析摘掉，表现为重启后工具不存在。
- `order` 别乱调：60 在 persona 之后、工具说明之前；5900 已压过 dsh-purge 的 5100，是全库最大。
- tail 默认 `compact`：短规则无损，长规则截到 120 字——尾部只为提醒，不值得付双份全文。
